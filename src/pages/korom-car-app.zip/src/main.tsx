import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import  { BrowserRouter, Routes, Route } from 'react-router-dom'
import { ToastContainer } from 'react-toastify'
import NotFoundPage from './pages/errors/NotFoundPage'
import AllCar from './pages/AllCar'
import Cart from './pages/Cart'
import EditCar from './pages/EditCar'
import NewCar from './pages/NewCar'
import OneCar from './pages/OneCar'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AllCar />} />
        <Route path="/car/:id" element={<OneCar />} />
        <Route path="/edit-car/:id" element={<EditCar />} />
        <Route path="/new-car" element={<NewCar />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
    <ToastContainer theme="colored" />
  </StrictMode>
)
