const AllCar = () => {
  return <div>All Car Page</div>
}

export default AllCar;