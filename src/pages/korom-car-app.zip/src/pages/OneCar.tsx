const OneCar = () => {
  return <div>One Car Page</div>
}

export default OneCar;