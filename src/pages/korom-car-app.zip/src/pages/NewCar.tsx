const NewCar = () => {
  return <div>New Car Page</div>
}

export default NewCar;