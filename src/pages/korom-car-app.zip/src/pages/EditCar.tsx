const EditCar = () => {
  return <div>Edit Car Page</div>
}

export default EditCar;