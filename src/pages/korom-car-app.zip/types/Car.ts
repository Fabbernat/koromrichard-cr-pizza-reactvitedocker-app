export type Car = {
    id: number;
    marka: string;
    modell: string;
    evjarat: number;
    futas_km: number;
    uzemanyag: string;
    valto: string;
    szin: string;
    ar: number;
    images: string[];
    leiras: string;
}